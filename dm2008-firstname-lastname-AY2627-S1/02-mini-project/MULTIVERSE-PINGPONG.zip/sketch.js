// -------- GlOBAL VARIABLES -------- //
let gameRestarted = false;
let gameArray = [];
let gameState = "start";
let maxScore;
let maxRounds = 1;
let roundNumber;

let time;
let wait = 1500;
let wait2 = 2500;
let ballMaxVel = 30;
let restartTimerStarted = false;

let divisionStep; // How many instances of Pong should be running

let leftScore = 0;
let rightScore = 0;
let ballDirection;

// -------- SCREEN DIVISION -------- //

let indexDivider;
let isEven;
let screenDividerX;
let screenDividerY;
let totalScreens;
let rowMemoryNumber = 0;

// --------------------------------- //

// -------- PADDLE -------- //

let paddleSpawnPosX;
let paddleSpawnPosY;

let defaultPaddleWidth
let defaultPaddleHeight

// -------------- MUSIC --------------- //
let startSFX
let menuSelectSFX
let bounceSFX
let playerScoresSFX
let startMusic
let font

// ------------------------ //

let playPNG;


async function setup() {
  createCanvas(1920, 1080);

  ballDirection = random([-1, 1]);

  time = millis();
startSFX = await loadSound ('/assets/freesound_community-game-start-6104.mp3');
menuSelectSFX = await loadSound ('/assets/creatorshome-select-001-337218.mp3');
bounceSFX = await loadSound ('/assets/dragon-studio-tennis-ball-hit-386155.mp3');
playerScoresSFX = await loadSound('/assets/eaglaxle-gaming-victory-464016.mp3')
startMusic = await loadSound ('/assets/moodmode-retro-game-arcade-236133.mp3');
font =  await loadFont('/assets/Minecraft.ttf');
playPNG = await loadImage ('assets/play.png');
console.log(playPNG);

  divisionStep = 1;

  updateScreenDivision();


  for( let i = 0; i < totalScreens; i ++ ) {
    gameArray.push(new Game(i));
  }


}

function draw() {
  console.log(divisionStep);

  background(18);

  handleInput();

  if ( gameState === "gameOver") {
    if ( leftScore > rightScore ) {
    textAlign(CENTER, CENTER)
    textSize(68);
    fill(255);
    text("PLAYER 1 WINS", width/2, height/2);
    }

    if ( rightScore > leftScore) {
    textAlign(CENTER, CENTER)
    textSize(68);
    fill(255);
    text("PLAYER 2 WINS", width/2, height/2);    
    }

    if ( leftScore === rightScore) {
    textAlign(CENTER, CENTER)
    textSize(68);
    fill(255);
    text("NOBODY WINS", width/2, height/2);
    }

    text("PRESS SPACEBAR TO RESTART", width/2, height/9 * 6)

    if (keyIsPressed && key === ' ' ) {
    gameState = "start";
    startSFX.play();
    leftScore = 0;
    rightScore = 0;
    gameRestarted = true;
    roundNumber = 0;
    divisionStep = 0;
    }
  }
  
  if ( gameState === "start") {
    time = millis();
    rowMemoryNumber = 0;
    divisionStep = 1;
    updateScreenDivision();        
    gameArray = [];
      for (let i = 0; i < totalScreens; i++) {
        gameArray.push(new Game(i));
      }    
    roundNumber = 0;    

    
    if (!keyIsPressed) {
      gameRestarted = false;
    }
    
    textAlign(CENTER, CENTER)
    textSize(68);
    fill(255);
    textFont(font);
    text("PRESS SPACEBAR TO START", width/2, height/2);
 

    textSize(42);
    fill(255);
    text(`Max Rounds: ${maxRounds}`, width/2, height/9 * 6);
    textSize(24);    
    text(`Use arrow keys to change`, width/2, height/15 * 11);    
    imageMode(CENTER);
    push();
    translate((width/8)*3, height/9 * 6);
    tint(255);
    rotate(PI);    
    image(playPNG, 0, 0, 64, 64);
    pop();
    push();
    translate(width - (width/8)*3, height/9 * 6);
    tint(255);    
    image(playPNG, 0, 0, 64, 64);
    pop();

    if (keyIsPressed && key === ' ' && gameRestarted === false) {
      updateScreenDivision();
      gameState = "playing";
      startSFX.play();
      startMusic.loop();
      startMusic.play();
      console.log("divNumber is " + divisionStep);
      roundNumber = 1;
      console.log("roundNumber is " + roundNumber)

    }



  }

  if ( gameState === "roundOver") {

    textAlign(CENTER, CENTER)
    textSize(68);
    fill(255);
    text("PRESS SPACEBAR TO BEGIN NEXT ROUND", width/2, height/2);
  

    if (keyIsPressed && key === ' ') {
      
      restartTimerStarted = true;
      time = millis();
      gameState = "playing";
      divisionStep += 1;        

      ballDirection = random([-1, 1]);
      updateScreenDivision();

      rowMemoryNumber = 0;
      gameArray = [];
      startSFX.play();
      roundNumber += 1;
      console.log("roundNumber is " + roundNumber)      

      for (let i = 0; i < totalScreens; i++) {
        gameArray.push(new Game(i));
      }
    }
  }

  if ( gameState === "playing" ) {




  for( let i = 0; i < gameArray.length; i ++) { //Draw each game

    if ( gameArray[i].ball.isEnd === false ) {

    gameArray[i].update();
    gameArray[i].show();

    if ( millis() - time >= wait2) {
      gameArray[i].ball.update();
      gameArray[i].ball.checkWallBounce();
      gameArray[i].ball.checkPaddleBounce(gameArray[i].leftPaddle);
      gameArray[i].ball.checkPaddleBounce(gameArray[i].rightPaddle);
      }

    let speed = gameArray[i].ball.vel.mag();

    
    if ( gameArray[i].ball.checkPaddleBounce(gameArray[i].leftPaddle) === true && gameArray[i].ball.vel.x < 0)
      {
        bounceSFX.play();
        if (mag(gameArray[i].ball.vel.x, gameArray[i].ball.vel.y) < ballMaxVel) {
          speed *= 1.1
        gameArray[i].ball.vel.x = speed *  cos(gameArray[i].ball.angle);
        gameArray[i].ball.vel.y = speed *  sin(gameArray[i].ball.angle);            
        }
          else {
        gameArray[i].ball.vel.x = speed * cos(gameArray[i].ball.angle);
        gameArray[i].ball.vel.y = speed * sin(gameArray[i].ball.angle);            
          }
      }

    if ( gameArray[i].ball.checkPaddleBounce(gameArray[i].rightPaddle) === true && gameArray[i].ball.vel.x > 0)
      {
        bounceSFX.play();
        if (mag(gameArray[i].ball.vel.x, gameArray[i].ball.vel.y) < ballMaxVel) {
          speed *= 1.1
        gameArray[i].ball.vel.x = -speed * cos(gameArray[i].ball.angle);
        gameArray[i].ball.vel.y = speed * sin(gameArray[i].ball.angle);     
        }
          else {  
        gameArray[i].ball.vel.x = -speed * cos(gameArray[i].ball.angle);
        gameArray[i].ball.vel.y = speed * sin(gameArray[i].ball.angle);          
          }
      }

    if ( gameArray[i].ball.isOutOfBounds() === true ) {
      gameArray[i].ball.end();
       }
      }  
    }

    textAlign(CENTER, CENTER)
    textSize(512);
    fill(255, 255, 255, 75); 
    text(leftScore, width/4, height/2)

    textAlign(CENTER, CENTER)
    textSize(512);
    fill(255, 255, 255, 75);
    text(rightScore, (width/4 * 3), height/2)

  }

  if ( gameArray.every(game => game.ball.isEnd === true) ) {
      if (restartTimerStarted === false) {
      time = millis();
      restartTimerStarted = true;      
      }
      if ( millis() - time >= wait) {
      restartTimerStarted = false;
      if ( roundNumber === maxRounds) {
        gameState = "gameOver";
        divisionStep = 1;
      }
      else {
      gameState = "roundOver";        
      }
      }


    if ( millis() - time >= wait) {
    gameArray.forEach(game => {game.ball.isEnd = false;
      game.ball.vel = createVector(random(0.9, 1.3) * game.ball.xSpeed * ballDirection, random(1, 1.1) * game.ball.ySpeed *([random([-1, 1])]))
      
      game.leftPaddle.reset(0);
      game.rightPaddle.reset((game.screenSize.x/16 * 14));
      ;

    })
    restartTimerStarted = false;
    }
   }
}

 /* ----------------- Input ----------------- */
function handleInput() {
  // Left paddle: W (up) and S (down) — use keyIsDown() with the key's character
  if (keyIsDown("w")) {
      for( let i = 0; i < gameArray.length; i ++) {
        gameArray[i].leftPaddle.vy =  -(gameArray[i].leftPaddle.speed);
      }
    }
     
  if (keyIsDown("s")) {
      for( let i = 0; i < gameArray.length; i ++) {
        gameArray[i].leftPaddle.vy =  (gameArray[i].leftPaddle.speed);
      }
    }

  if (keyIsDown(UP_ARROW)) {
      for( let i = 0; i < gameArray.length; i ++) {
        gameArray[i].rightPaddle.vy =  -(gameArray[i].rightPaddle.speed);
      }
    }

  if (keyIsDown(DOWN_ARROW)) {
      for( let i = 0; i < gameArray.length; i ++) {
        gameArray[i].rightPaddle.vy = (gameArray[i].rightPaddle.speed);
      }
    }
  }

function keyReleased() {
      for( let i = 0; i < gameArray.length; i ++) {
        gameArray[i].leftPaddle.vy  = 0;
        gameArray[i].rightPaddle.vy = 0;
      }
    }

function keyPressed() {

    if (gameState === "start") {

    if (keyCode === 37 || keyCode === 65) {
      menuSelectSFX.play();
      if (maxRounds > 1) {
        maxRounds--;
      }
    }

    if (keyCode === 39 || keyCode === 68) {
      menuSelectSFX.play();      
      if (maxRounds < 4) {
        maxRounds++;
      }
    }
  }
}

  // Right paddle: UP_ARROW and DOWN_ARROW — same pattern as left paddle

function updateScreenDivision() {

    if ( divisionStep % 2 === 0 ) {
      isEven = true; 
    }
    
    else {
      isEven = false;
    }

    if ( isEven === true) {
      screenDividerX = pow(2, (divisionStep / 2));

      if( divisionStep === 2 ) {
        screenDividerY = 1;
      }
      else if ( divisionStep != 1 ) {
        screenDividerY = pow(2, (divisionStep -2)/2);
      }
    }
    else if ( divisionStep === 1 ) {
      screenDividerX = 1;
      screenDividerY = 1;
    }
    else {
      screenDividerX = pow(2, ((divisionStep -1) / 2));
      screenDividerY = screenDividerX;
    }

  totalScreens = screenDividerX * screenDividerY;

}

class Game {
  constructor(index) {
    // Index is used to identify each unique instance of Game.
    this.index = index;

    if (index % screenDividerX === 0) {
      this.screenPosX = 0;
    }
    else {
      this.screenPosX = (index % screenDividerX) * (width / screenDividerX);
    }

    if( index != 0 && (index % screenDividerX) === 0) {
      rowMemoryNumber += 1;
    }


    this.screenSize = createVector(width / screenDividerX, height / screenDividerY);


    defaultPaddleWidth = this.screenSize.x / 52;
    defaultPaddleHeight = this.screenSize.y / 6;

    //Positioning of the screen

  
    this.screenPosY = this.screenSize.y * rowMemoryNumber;


    //Paddle
    this.paddleSpawnPosX = this.screenPosX + this.screenSize.x/16;
    this.paddleSpawnPosY = this.screenPosY + this.screenSize.y/2;

    this.leftPaddle = new Paddle(this.paddleSpawnPosX, this.paddleSpawnPosY, defaultPaddleWidth, defaultPaddleHeight, this);
    this.rightPaddle = new Paddle(this.paddleSpawnPosX + (this.screenSize.x/16 * 14), this.paddleSpawnPosY, defaultPaddleWidth, defaultPaddleHeight, this);


    //Ball


    this.ballSpawnPos = createVector(0, 0);
    this.ballSpawnPos.x = this.screenPosX + this.screenSize.x/2;
    this.ballSpawnPos.y = this.screenPosY + this.screenSize.y/2;
    this.ballRadius = this.screenSize.x/42

    this.ball = new Ball(this.ballSpawnPos.x, this.ballSpawnPos.y, this.ballRadius, this);
  }

  drawBackground() {
    
  }

  show() {

    rectMode(CORNER);
    fill(0, 220, 0); 
    rect(this.screenPosX, this.screenPosY, this.screenSize.x, this.screenSize.y);        
    fill(0, 0, 255); 
    rect(this.screenPosX, this.screenPosY, this.screenSize.x/2, this.screenSize.y);


    push();

    beginClip();

    rect(this.screenPosX, this.screenPosY, this.screenSize.x, this.screenSize.y);    

    endClip();

    this.leftPaddle.show();
    this.rightPaddle.show();

    if ( millis() - time >= wait) {
      this.ball.show();
    }

    pop();
  //  startMusic.play();
  }

  update() {
    this.leftPaddle.update();
    this.rightPaddle.update();
  }
}

class Paddle {
  constructor(posX, posY, width, height, parentGame) {
    this.posX = posX;
    this.posY = posY;
    this.width = width;
    this.height = height;
    this.vy = 0;
    this.speed = parentGame.screenSize.y/46;
    this.parentGame = parentGame;

  }

  update() {
    this.posY += this.vy;
    this.posY = constrain(this.posY, this.parentGame.screenPosY + defaultPaddleHeight/2, (this.parentGame.screenPosY + this.parentGame.screenSize.y - defaultPaddleHeight/2));
  }

  show() {
    rectMode (CENTER);
    fill(255);
    rect(this.posX, this.posY, this.width, this.height);

  }

  reset(offsest) {
    this.posY = this.parentGame.paddleSpawnPosY;
    this.posX = this.parentGame.paddleSpawnPosX + offsest;
  }
}

class Ball {
  constructor(x, y, r, parentGame) {
    this.pos = createVector(x, y);
    this.r = r;
    this.xSpeed = parentGame.screenSize.x/250;
    this.ySpeed = parentGame.screenSize.y/540;
    this.parentGame = parentGame;
    this.dist = createVector(0, 0);
    this.isTopBottom;
    this.isEnd = false;
    this.hitYPosition;
    this.normalizedhitYPosition;
    this.maxAngle = radians(60);
    this.angle;

    // Give the ball a random starting direction to get it moving
    // this.vel = createVector(random([-1, 1]) * this.xSpeed, random([-1, 1]) * this.ySpeed);

    this.vel = createVector(random(0.9, 1.3) * this.xSpeed * ballDirection, random(1, 1.1) * this.ySpeed *([random([-1, 1])]));

  }
  
  checkWallBounce() {
    // Bounce off top and bottom walls
    if (this.pos.y - this.r <= this.parentGame.screenPosY || this.pos.y + this.r >= this.parentGame.screenPosY + this.parentGame.screenSize.y) {
      this.vel.y *= -1;

      this.pos.y = constrain(this.pos.y, this.parentGame.screenPosY + this.r, this.parentGame.screenPosY + this.parentGame.screenSize.y - this.r);
    }
  }

  checkPaddleBounce(paddle) {
    this.dist.x = Math.abs(this.pos.x - paddle.posX);
    this.dist.y = Math.abs(this.pos.y - paddle.posY);

    this.hitYPosition = this.pos.y - paddle.posY;
    this.normalizedhitYPosition = constrain(this.hitYPosition/defaultPaddleHeight, -1, 1);
    this.angle = this.normalizedhitYPosition * this.maxAngle;
    

    if (this.dist.x > (paddle.width/2 + this.parentGame.ballRadius)) { return false; }
    if (this.dist.y > (paddle.height/2 + this.parentGame.ballRadius)) { return false; }    
//bounceSFX.play();
    if (this.dist.x <= (paddle.width/2)) { 
      this.isTopBottom = true;
      return true; }
    if (this.dist.y <= (paddle.height/2)) { return true; }     

    this.dx = this.dist.x - paddle.width/2;
    this.dy = this.dist.y - paddle.height/2;
    
    return (this.dx * this.dx + this.dy * this.dy <= (this.r * this.r));
  }

  isOutOfBounds() {
    if ( this.pos.x < this.parentGame.screenPosX - this.r) {
      rightScore += 1;
      return true;
    } 
    else if ( this.pos.x > this.parentGame.screenPosX + this.parentGame.screenSize.x + this.r ) {
       leftScore += 1;
        return true;
      }
    else {
      return false;
    }
  }

  update() {
    if ( this.isEnd === false ) {
    this.pos.add(this.vel);
    }
  }

  show() {
    rectMode (CENTER);
    fill(255);
    circle(this.pos.x, this.pos.y, this.r * 2);
  }

  end() {
    this.isEnd = true;
    this.pos.x = this.parentGame.screenPosX + this.parentGame.screenSize.x/2;
    this.pos.y = this.parentGame.screenPosY + this.parentGame.screenSize.y/2;
  }


}