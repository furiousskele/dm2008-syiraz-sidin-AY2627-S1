//PRESS SPACEBAR

// DM2008 — Activity 2b
// Pattern Making (40 min)
//
// Use a for loop to draw a repeating pattern of shapes.
// Add a condition to introduce variation, and one interaction that changes the rule.
//
// Stretch: try a second row, or turn your row into a 2D grid.

function setup() {
  createCanvas(400, 400);
}

let fillColourMainRow = '#FFD61C';
let fillColourAuxRow = '#FFFFFF';
let divisions = 5;
let spacing = 50;
let evenOdd = 0;

function keyPressed() {
  if(key == ' ') {
      if(fillColourMainRow == '#FFFFFF') {
      fillColourMainRow = '#FFD61C';
        evenOdd = 1;
      if(fillColourAuxRow == '#FFD61C') {
      fillColourAuxRow = '#FFFFFF';
      }
    }
      else if(fillColourMainRow == "#FFD61C") {
      fillColourMainRow = '#FFFFFF'; 
        evenOdd = 0;
      if(fillColourAuxRow == '#FFFFFF') {
      fillColourAuxRow = '#FFD61C';
      }
    }
  }
}

function draw() {
  background(77, 106, 224);
  noStroke()

  let ellipseSize;
  let spacingX = width/divisions;
  let a;
  let b;
  let t = 0; 
  
  t = 0.5 * sin(0.05 * frameCount) + 0.5; //Giving me a value from 0 to 1 in a sine pattern based on frame count
  
    function easeInOutQuart(t) {
    return t < .5 ? 8 * t * t * t * t : 1 - 8 * (--t) * t * t * t
    } //Formula for the type of easing in and out for ball animation

  for(let i = 0; i < divisions + 1; i ++) {
    a = i * spacingX - spacing;
    b = i * spacingX + spacing;
      //Create lerp positions based on spacingX and i for each ellipse.

    if(i%2 == evenOdd) {
      ellipseSize = 50;
    }
    else {
      ellipseSize = 35;
    }

    fill(fillColourMainRow)
    
    ellipse(lerp(a, b, easeInOutQuart(t)), 200, ellipseSize, ellipseSize);

    fill(fillColourAuxRow)
    
    ellipse(lerp(a, b, 1 - easeInOutQuart(t)), 300, 50, 50);
    
    ellipse(lerp(a, b, 1 - easeInOutQuart(t)), 100, 50, 50);
  }
}