// DM2008 — Activity 1a
// Simple Creatures (20 min)

// Run the sketch, then click on the preview to enable keyboard
// Use the 'Option' ('Alt' on Windows) key to view or hide the grid
// Use the 'Shift' key to change overlays between black & white
// Write the code for your creature within the space provided

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(255);
  noStroke();
  fill(255, 60, 0)
  ellipse(200, 200, 90, 110)
    ellipse(230, 225, 100, 20)
  ellipse(200, 125, 80, 70)
  triangle(167, 125, 152, 89, 184, 101 )
  triangle(233, 125, 252, 89, 224, 101 )
  fill(70, 70, 70)
  triangle(180, 140, 220, 140, 200, 160)
  circle(180, 120, 8)
  circle(220, 120, 8)
  stroke(70, 70, 70)
  line(200, 150, 140, 140)
  line(200, 150, 140, 160)
    line(200, 150, 260, 140)
      line(200, 150, 260, 160)
  
  
  
  // YOUR CODE HERE
  
  // YOUR CODE HERE
  
  helperGrid(); // do not edit or remove this line
}
