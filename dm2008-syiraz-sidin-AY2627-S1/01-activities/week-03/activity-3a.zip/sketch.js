// PRESS MOUSE BUTTON TO ADD A BLINK


// DM2008 — Activity 3a [Guided]
// Array Sampler (25 min)
//
// An array stores a list of values — here it's colors, but it could be
// sizes, positions, or anything else.
// Press any key to cycle through the array one item at a time.
//
// Try these:
// - Replace the colors with your own values (sizes, positions, text).
// - Use mousePressed() instead of keyPressed().
// - Use push() to add new items or splice() to remove them.
// - Loop through the whole array to draw all items at once.
//
// Stretch: visualize all items in the array simultaneously instead of one at a time.

let points = [];
let i = 0;
let pRandom;

function setup() {
  createCanvas(400, 400);
  
  let p1 = createVector(50, 100);
  let p2 = createVector(75, 200);
  let p3 = createVector(325, 310);
  
  points.push(p1);
  points.push(p2);
  points.push(p3);

}

function draw() {
  background(20, 20);

  stroke(255);
  strokeWeight(5);

    if(frameCount % (10) == 0) {
      point(points[i].x, points[i].y);

      strokeWeight(1);
      if(i < points.length - 1) {
      line(points[i].x, points[i].y, points[i+1].x, points[i+1].y);
      }

      else {
      line(points[i].x, points[i].y, points[0].x, points[0].y);
      }
      
      i += 1;
      if(i == points.length) {
        i = 0

      
    }
  }
}

function pushRandom() {
  pRandom = createVector(random(0, 400), random(0, 400))
  points.push(pRandom);
  }

function mousePressed() {
  pushRandom();
  console.log(points);
  }
