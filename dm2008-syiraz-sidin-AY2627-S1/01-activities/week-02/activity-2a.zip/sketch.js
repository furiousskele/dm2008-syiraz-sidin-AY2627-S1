// DM2008 — Activity 2a
// Mode Switch (20 min)
//
// Use keys 1, 2, 3 to switch between at least 3 modes.
// Each mode should change more than just the background — think fill, size, or motion.
//
// Stretch: add a 4th mode, or make the ellipse change shape between modes.

let x = 0;       // ellipse x-position
let size = 50;   // ellipse size
let bgColor;     // background color, changed by key presses

function setup() {
  createCanvas(400, 400);
  bgColor = color(220);
}
  let fillColour = 0;
  let isMoving = true;
  let drawnShape = "ellipse";

function draw() {
  background(bgColor);
  
  fill(fillColour);
  ellipse(x, height / 2, size);

  if(isMoving == true) {
      x += 2;
  }

  if (x > width + size / 2) {
    x = 0;
  }

  console.log(drawnShape);
}

// Keys 1, 2, 3 change the background color
function keyPressed() {
  switch (key) {
    case "1":
      bgColor = color(200, 100, 100);
      fillColour = 0
      isMoving = true
      drawnShape = "ellipse"
      break; // red
    case "2":
      bgColor = color(100, 200, 100);
      fillColour = 170
      isMoving = false
      drawnShape = "triangle"
      break; // green
    case "3":
      bgColor = color(100, 100, 200);
      fillColour = 255
      isMoving = true
      drawnShape = "rectangle"
      break; // blue
    default:
      bgColor = color(220); // grey
  }
}
