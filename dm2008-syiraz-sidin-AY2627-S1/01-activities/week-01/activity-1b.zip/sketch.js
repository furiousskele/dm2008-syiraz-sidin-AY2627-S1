// DM2008 — Activity 1b [Georg Nees]
// Learning By Making (30 min)

let x;
let y;
let w;
let i = 0;
let maxAmt = 200

function setup() {
  createCanvas(800, 800)
  background(35);
}

function draw() {
  
  let zoom = 1;
  let ptCenterX = width/2;
  let ptCenterY = height/2;
  
  let mouseDist = dist(ptCenterX, ptCenterY, mouseX, mouseY);
  
  
  let randomR = random(0, 255);
  let randomG = random(0, 255);
  let randomB = random(0, 255);
  
  x = random(width);
  y = random(height);
  w = random(10, 80);

  v = i % 30;
  if(v == 0) {
  strokeWeight(1);
  stroke(mouseDist, 0, 0);
  line(ptCenterX, ptCenterY, mouseX, mouseY);
  }

  

  if(i<maxAmt) {
      i = i + 1
      stroke(randomR, randomG, randomB);
      strokeWeight(random(0.5, 2));
      noFill();
      rect(x, y, w, w);
  }

  if(i == maxAmt) {
    clear()
    background(35)
    i = 0;
  }

  //console.log(i)
}