// DM2008 — Activity 4a [Guided]
// Bake a Cookie (30 min)
//
// A class is a blueprint — Cookie describes what every cookie has and can do.
// Your job is to complete the class, then add movement and a flavor randomizer.
//
// Suggested order:
// 1. Add the missing properties to the constructor (sz, x, y)
// 2. Fix show() so it uses this.flavor, this.x, this.y, this.sz
// 3. Implement move() and randomFlavor()
// 4. Wire them up in keyPressed() and mousePressed()
//
// Stretch: add a second cookie with different starting values.

let cookie;
let cookie2;
let moveFactor = 5;
let flavors = ["chocolate", "vanilla", "nasty monster"];
let angle = 0;

function setup() {
  createCanvas(400, 400);
  noStroke();
  cookie = new Cookie("chocolate", 80, width / 2, height / 2);
  cookie2 = new Cookie("nasty monster", 40, cookie.x, cookie.y);
}

function draw() {
  background(230);
  cookie.show();
  angle += 1;
  if(angle == 361) {
    angle = 0;
  }
  cookie2.x = cookie.x + 70 * sin(angle * 0.02);
  cookie2.y = cookie.y + 70 * cos(angle * 0.02);
  cookie2.show()
}

class Cookie {
  constructor(flavor, sz, x, y) {
    this.flavor = flavor;
    this.sz = sz;
    this.x = x;
    this.y = y;
  }

  show() {
    // Fix this method — it should use this.flavor, this.x, this.y, this.sz
    switch (this.flavor) {
      case "chocolate":
        fill(196, 146, 96);
        break;
      case "vanilla":
        fill(255, 223, 150);
        break;
      case "nasty monster" :
        fill (0, 130, 235);
        break;
      default:
        fill(220, 180, 120);
    }
    ellipse(this.x, this.y, this.sz);
  }

  // Add a move() method — update this.x or this.y based on which key is pressed
  move() {
    switch (key) {
    case "w" :
    this.y = this.y - moveFactor;
    break
    case "s" :
    this.y = this.y + moveFactor;
    break
    case "a" :
    this.x = this.x - moveFactor;
    break
    case "d" :
    this.x = this.x + moveFactor;
    }
  }

  // Add a randomFlavor() method — set this.flavor to one of at least 3 options
  randomFlavor() {
    cookie.flavor = random(flavors);
    cookie2.flavor = random(flavors);
    console.log(cookie.flavor);
  }
}

// Call cookie.move() when an arrow key is pressed
function keyPressed() {
  if(key === "w" || key === "s" || key === "a" || key === "d") {
    cookie.move();
    console.log(key);
  }
}

// Call cookie.randomFlavor() when the mouse is clicked
function mousePressed() {
  cookie.randomFlavor();
  cookie2.randomFlavor();
}