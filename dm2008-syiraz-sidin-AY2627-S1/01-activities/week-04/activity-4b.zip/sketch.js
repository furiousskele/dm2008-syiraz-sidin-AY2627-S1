let agents = [];

function setup() {
  createCanvas(600, 400);
  noStroke();
}
  
function draw() {
  background(0);

  for(let i = agents.length -1; i > -1; i--) {
    ellipse(agents[i].x, agents[i].y, 50, 50);
  }
}

class Particle {
  constructor(x, y) {
  this.x = x;
  this.y = y;   
  
  }
}

function mousePressed() {
  agents.push(new Particle(mouseX, mouseY));
  console.log(agents)
}


