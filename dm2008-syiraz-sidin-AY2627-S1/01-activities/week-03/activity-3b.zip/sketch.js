// ______________________________________________________________
// |============================================================|
// |                                                            |
// {--------------------=> CLICK TO BLOOM <=--------------------}
// |                                                            |
// |                                                            |
// {--------------------=> HOLD TO PULSATE <=-------------------}
// |\                                                          /|
// | \                                                        / |
// |  \______________________________________________________/  |
// |   \                                                    /   |
// |    \                                                  /    |
// |=====\________________________________________________/=====| 
// 

// DM2008 — Activity 3b
// One Function Wonder (30 min)
//
// Write a function that draws a shape or group of shapes.
// It should take at least one parameter — try x, y, size, or color.
// Call it several times with different values to create variation.
//
// Ideas: a simple face, a flower, a house, an icon.
// Example: myShape(100, 200, 50); myShape(300, 200, 80);
//
// Stretch: call your function inside a for loop to create a repeating pattern.

let r = 50;
let step;
let instances = 32;
let colourShifter = 0;
let storedFrame;
let currentFrame;
let positions = [];
let p;

function setup() {
  createCanvas(400, 400);
  rectMode(CENTER);
  step = PI/32;
  console.log(storedFrame);
}

function draw() {
  background(0,);
  
  // Call your function here with different values each time
  for(let i = 0; i < positions.length; i++) {
    myShape(positions[i].x, positions[i].y);
  }
  
  if(mouseIsPressed == true) {
    if(storedFrame === undefined) {
      storedFrame = frameCount;
      console.log(storedFrame)
        p = createVector(mouseX, mouseY);
        positions.push(p);
        console.log(positions);
    }
    let currentFrame = frameCount;

    colourShifter = (sin((currentFrame - storedFrame) * 0.02) + 1) * 255/2;


    
  }

  else {
    storedFrame = undefined;
  }
}



// Define your function outside draw()
// It can be called from anywhere in your sketch

function myShape(x, y) { 

  let angle = 0;
  
    stroke(colourShifter + 30, 0, 0);
  strokeWeight(5);


  for(let j = 0; j < instances; j ++) {

  r = 50 * sin(frameCount * 0.02 - j/2);
    
  u = x + r * cos(angle);
  v = y + r * sin(angle);
  
  point(u, v);

  angle = angle + step;    
  }
}