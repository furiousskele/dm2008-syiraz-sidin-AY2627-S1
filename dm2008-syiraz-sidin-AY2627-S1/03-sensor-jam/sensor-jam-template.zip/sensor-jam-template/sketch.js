let port; // Serial Communication port
let connectBtn;
let wasOpened = false; // tracks port state to update the button label

let sensorVal;
let circleSize = 50;
let targetSize = 50; // used for Option 2
let targetColour;
let img;
let dog;

let sensorSlider;
let sliderLabel;


async function setup() {
  img = await loadImage('/assets/dog.jpg');
  dog = await loadModel('/assets/dog.obj')

  createCanvas(windowWidth, windowHeight, WEBGL);
  port = createSerial(); // creates the Serial Port

  imageMode(CENTER);

  // Connection helpers
  connectBtn = createButton("Connect to Arduino");
  connectBtn.position(20, 20);
  connectBtn.mousePressed(connectBtnClick);


  // Sensor Simulation
  sensorSlider = createSlider(5, 100, 50, 1);
  sensorSlider.position(20, 70);
  sensorSlider.style('width', '200px');

  sliderLabel = createP('Simulated distance: 50 cm');
  sliderLabel.position(20, 85);  
}

function draw() {
  background(100);
  fill(targetColour, 0, 0);

  orbitControl();

  ambientLight(100, 100, 100);
  directionalLight(200, 200, 200, 1, 0.5, -1);
  directionalLight(70, 70, 100, -0.5, 1, 0.5)


  fill('lightblue');
  translate(0, 60, 0);
  scale(circleSize, -circleSize, circleSize);
  model(dog);

  ellipse(width / 2, height / 2, circleSize);


  image(img, width/2, height/2, circleSize, circleSize);

  updateConnectBtn();

  let val;

  // Receive data from Arduino
  if (port.opened()) {
    sensorVal = port.readUntil("\n");
    // Only log data that has information, not empty signals
    if (sensorVal[0]) {
      // Once you verify data is coming in,
      // disable logging to improve performance
      console.log(sensorVal);

      // use float() to convert the data from string to number
      // (Arduino must send ONE number per line, e.g. Serial.println(distVal))
    
      
      val = float(sensorVal);

    }
  } else {

    val = sensorSlider.value();

    sliderLabel.html(`Simulated distance ${val} cm`);

  };

      // Ignore anything that isn't a number (e.g. stray text or a partial line)
      if (!isNaN(val)) {
        // OPTION 1:
        // Update circle's size with sensor's data directly
        // Reduce delay() value in Arduino to get smoother changes
        // circleSize = val;

        // OPTION 2:
        // Update circle's size using lerp() to smoothly change values
        // This method even works with longer delay() values in Arduino

        // map distance (5-100cm) to circle size: closer = bigger
        targetSize = map(val, 5, 100, 400, 50);
        targetColour = map(val, 5, 100, 50, 255);
        // last value in lerp() controls speed of change
        circleSize = lerp(circleSize, targetSize, 0.1);
      }
    }

// DO NOT REMOVE THIS FUNCTION
function connectBtnClick() {
  // If port is not already open, open on click,
  // otherwise close the port
  // (the button label is updated in updateConnectBtn())
  if (!port.opened()) {
    port.open(9600); // opens port with Baud Rate of 9600
  } else {
    port.close();
  }
}

// Keeps the button in sync with the real port state, since opening is
// asynchronous and can fail (picker cancelled, port busy, board unplugged)
function updateConnectBtn() {
  let isOpened = port.opened();
  if (isOpened === wasOpened) return;
  wasOpened = isOpened;

  connectBtn.html(isOpened ? "Disconnect Arduino" : "Connect to Arduino");
  if (isOpened) {
    connectBtn.addClass("connected");
  } else {
    connectBtn.removeClass("connected");
  }
}
