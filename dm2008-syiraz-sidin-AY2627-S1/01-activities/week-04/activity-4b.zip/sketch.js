let particleArray = [];
let orbiterArray = [];

function setup() {
  createCanvas(600, 400);
  noStroke();

  angleMode(RADIANS);

  rowHeight = height/3;
  columnWidth = width/3
  for (let i = 0; i < 3; i += 1) {
    createParticle(createVector(rowHeight, columnWidth * i + 1));    
  }

  for (let i = 0; i < 3; i += 1) {
    createParticle(createVector(rowHeight * 2, columnWidth * i + 1));    
  }  

  for (let i = 0; i < 3; i += 1) {
    createParticle(createVector(rowHeight * 3, columnWidth * i + 1));    
  }    
}
  
function draw() {
  background(0);

  show();
  update();
}

function show() {
  for (let i = 0; i < particleArray.length; i += 1) {
    particleArray[i].show();
  }
}

function update() {
  for (let i = 0; i < particleArray.length; i += 1) {
    particleArray[i].update();
  }  
}


function mouseClicked() {
  createParticle(createVector(mouseX, mouseY));
  console.log("mouseclicked");
  console.log(particleArray);
}

function createParticle(pos) {
  particleArray.push(new Particle(pos));
}

class Particle {
  constructor(pos) {
    this.pos = pos
    this.orbiterArray = [];
    this.orbiterQuantity = 3;
    this.size = 30;

    this.createOrbiters();
  }

  createOrbiters() {
    for (let i = 0; i < this.orbiterQuantity; i += 1) {
      this.orbiterArray.push(new Orbiter(TWO_PI/this.orbiterQuantity * i, this.pos));
    }
  }

  show() {
    circle(this.pos.x, this.pos.y, this.size)

    for (let i = 0; i < this.orbiterArray.length; i += 1) {
      this.orbiterArray[i].show();
    }
  }

  update() {
    for (let i = 0; i < this.orbiterArray.length; i +=1) {
      this.orbiterArray[i].update();
    }
  }
}

class Orbiter {
  constructor(angle, parentPos) {
    this.size = 10;
    this.parentPos = parentPos;
    this.distance = 30;
    this.angle = angle;
    this.pos = createVector(0, 0);
    this.pos.x = cos(this.angle) * this.distance + parentPos.x
    this.pos.y = sin(this.angle) * this.distance + parentPos.y
  }

  show() {
    circle(this.pos.x, this.pos.y, this.size);
  }

  update() {
    this.angle += 0.02;
    this.updatePosition();
  }

  updatePosition() {
    this.pos.x = cos(this.angle) * this.distance + this.parentPos.x;
    this.pos.y = sin(this.angle) * this.distance + this.parentPos.y;
  }

}




